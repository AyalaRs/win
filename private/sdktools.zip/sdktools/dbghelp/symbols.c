/*++

Copyright (c) 1995  Microsoft Corporation

Module Name:

    symbols.c

Abstract:

    This function implements a generic simple symbol handler.

Author:

    Wesley Witt (wesw) 1-Sep-1994

Environment:

    User Mode

--*/
#ifdef _WIN64
#define _INC_TIME
#endif
#include "private.h"
#include "symbols.h"

#include "cvr.h"
#include "symtypeutils.h"
#define printf(f,...) DbgPrint(f,__VA_ARGS__)

int __stdcall
MultiByteToWideChar(
 int   CodePage,
 int   dwFlags,
 char* lpMultiByteStr,
 int    cbMultiByte,
 char* lpWideCharStr,
 int    cchWideChar
);

PWSTR
AnsiToUnicode(
    PSTR pszAnsi
    )
{
    UINT uSizeUnicode;
    PWSTR pwszUnicode;

    if (!pszAnsi) {
        return NULL;
    }

    uSizeUnicode = (strlen(pszAnsi) + 1) * sizeof(wchar_t);
    pwszUnicode = malloc(uSizeUnicode);

    if (*pszAnsi && pwszUnicode) {

        if (!MultiByteToWideChar(CP_ACP, MB_COMPOSITE,
            pszAnsi, strlen(pszAnsi),
            pwszUnicode, uSizeUnicode)) {

            // Error. Free the string, return NULL.
            free(pwszUnicode);
            pwszUnicode = NULL;
        }
    }

    return pwszUnicode;
}

BOOL
SymDoEnumCallBack(
    IN PROC     EnumSymbolsCallback,
    IN PB       SymbolName,
    IN DWORD64  addr,
    IN unsigned type,
    IN DWORD    size,
    IN PVOID    UserContext,
    IN BOOL     Use64,
    IN BOOL     CallBackUsesUnicode
    )
{
	BOOL fnext;
	PWSTR pszTmp=NULL;
	
	if (CallBackUsesUnicode)
	{
		 pszTmp = AnsiToUnicode(SymbolName);
	}
	
	if (Use64)
		fnext = (*(PSYM_ENUMSYMBOLS_CALLBACK64)EnumSymbolsCallback) (
				(pszTmp?pszTmp:SymbolName),
				(addr?addr:type),
				size,
				UserContext );
	else
		fnext = (*(PSYM_ENUMSYMBOLS_CALLBACK)EnumSymbolsCallback) (
				(pszTmp?pszTmp:SymbolName),
				(addr?addr:type),
				size,
				UserContext );

done:
	if (pszTmp)
		free(pszTmp);
	return fnext;
}

char gSymPath[260];

BOOL
SymSetSearchPath(
    IN HANDLE  hProcess,
    IN char*   sympath
    )
{
	RtlMoveMemory(gSymPath,sympath,strlen(sympath)+1);
}

BOOL
SympEnumerateTypes(
    IN HANDLE  hProcess,
    IN ULONG64 BaseOfDll,
    IN PROC    EnumSymbolsCallback,
    IN PVOID   UserContext,
    IN BOOL    Use64,
    IN BOOL    CallBackUsesUnicode
    )
{

    PIMGHLP_DEBUG_DATA  pIDD;
    __try {
		pIDD = malloc(sizeof(*pIDD));
		memset(pIDD,0,sizeof(*pIDD));
		pIDD->InProcImageBase = BaseOfDll;
		pIDD->hProcess   = hProcess;
		pIDD->SymbolPath = gSymPath;

		
		if (ProcessDebugInfo(pIDD,NULL)) 
		{
			PB       dataSym = NULL;
			PB       SymbolName;
			DWORD    SymCount = 0;
			DWORD    size = 0;
			DWORD64  addr = 0;
			unsigned type = 0;

			ProcessPdbDebugInfo(pIDD);
			//globals
			if ( pIDD->pGlobals)
			{
				for(dataSym =  NULL;
					dataSym = GSINextSym( pIDD->pGlobals, dataSym),
					dataSym != NULL;) 
				{
					SYTI* psyti = psytiFromPsym(dataSym);
					if (psyti->ibName != 0)
						SymbolName = dataSym + psyti->ibName;
					else
						SymbolName = psyti->sz;
					
					if (!(SymDoEnumCallBack(
										EnumSymbolsCallback,
										SymbolName,
										addr,
										psyti->rectyp,
										size,
										UserContext,
										Use64,
										CallBackUsesUnicode)))
						break;
				}
			}
			//public symbol
			if (pIDD->pGsi)
			{
				for(dataSym =  NULL;
					dataSym = GSINextSym( pIDD->pGsi, dataSym),
					dataSym != NULL;) 
				{
					SYTI* psyti = psytiFromPsym(dataSym);
					
					//pass a public symbol
					if (psyti->rectyp==S_PUB32) 
						continue;
					
					if (!(fGetSymName(dataSym,&SymbolName)))
						continue;
					
					if (!(SymDoEnumCallBack(
										EnumSymbolsCallback,
										SymbolName,
										addr,
										psyti->rectyp,
										size,
										UserContext,
										Use64,
										CallBackUsesUnicode)))
						break;
				}
			}
			//enum tpi
			if (pIDD->pTpi && 
				TypesSupportQueryTiForUDT(pIDD->pTpi))
			{
				TI    ti;
				PB* pb;
				for(ti = TypesQueryTiMinEx(pIDD->pTpi);
					ti < TypesQueryTiMacEx(pIDD->pTpi);
					ti++) 
				{
					PB fpb;
					PB fieldname;
					TI fti;
					BOOL status=
					TypesQueryPbCVRecordForTiEx(pIDD->pTpi,ti,&pb);
					
					
					if (!status)
					{
#if DBG
if (IsDebuggerPresent())
__debugbreak();
#endif
					}
						
					
					fti = tiFListFromUdt(pb);
					
					if (fti==T_NOTYPE)
						continue;
						
					SymbolName = szUDTName(pb);
					
					if (!SymbolName)
						SymbolName = stUDTName(pb);
					
					if (!(SymDoEnumCallBack(
										EnumSymbolsCallback,
										SymbolName,
										((PTYPE)pb)->leaf,
										0,
										size,
										UserContext,
										Use64,
										CallBackUsesUnicode)))
						break;
#if DBG
if (IsDebuggerPresent())
__debugbreak();
#endif
					if (TypesQueryPbCVRecordForTiEx(pIDD->pTpi,fti,&fpb))
					{
						IB ib=0;
						USHORT k;
						lfFieldList* pfl = &((PTYPE)fpb)->leaf;
						
						printf("%s\n",SymbolName);
						for (k=0;k<*(USHORT*)&((PTYPE)pb)->data[0];k++)
						{
							fieldname = stMemberName(&pfl->data[ib]);
							printf(" %04X %s\n",*(USHORT*)(fieldname-sizeof(USHORT)),fieldname);
							//get pbend tii.cpp
							//assert leaf as sz string
							ib = fieldname + strlen(fieldname) +1;
							
							if (*(PB)ib >0xF0)
								ib += *(PB)ib & 0xF;
							ib -= (IB)&pfl->data[0];
						}
					}
					
					
					
					
				} //pTpi enum
				
			} //pIDD->pTpi
			
			return TRUE;
		} //SymPdb



    } __except (EXCEPTION_EXECUTE_HANDLER) {


        return FALSE;

    }

    return TRUE;
}



BOOL
IMAGEAPI
SymEnumerateTypes(
    IN HANDLE                       hProcess,
    IN ULONG                        BaseOfDll,
    IN PSYM_ENUMSYMBOLS_CALLBACK    EnumSymbolsCallback,
    IN PVOID                        UserContext
    )

{
    return SympEnumerateTypes(hProcess, BaseOfDll, (PROC)EnumSymbolsCallback, UserContext, FALSE, FALSE);
}

BOOL
IMAGEAPI
SymEnumerateTypesW(
    IN HANDLE                       hProcess,
    IN ULONG                        BaseOfDll,
    IN PSYM_ENUMSYMBOLS_CALLBACKW   EnumSymbolsCallback,
    IN PVOID                        UserContext
    )
{
    return SympEnumerateTypes(hProcess, BaseOfDll, (PROC)EnumSymbolsCallback, UserContext, FALSE, TRUE);
}

BOOL
IMAGEAPI
SymEnumerateTypes64(
    IN HANDLE                       hProcess,
    IN ULONG64                      BaseOfDll,
    IN PSYM_ENUMSYMBOLS_CALLBACK64  EnumSymbolsCallback,
    IN PVOID                        UserContext
    )
{
    return SympEnumerateTypes(hProcess, BaseOfDll, (PROC)EnumSymbolsCallback, UserContext, TRUE, FALSE);
}

BOOL
IMAGEAPI
SymEnumerateTypesW64(
    IN HANDLE                       hProcess,
    IN ULONG64                      BaseOfDll,
    IN PSYM_ENUMSYMBOLS_CALLBACK64W EnumSymbolsCallback,
    IN PVOID                        UserContext
    )
{
    return SympEnumerateTypes(hProcess, BaseOfDll, (PROC)EnumSymbolsCallback, UserContext, TRUE, TRUE);
}
