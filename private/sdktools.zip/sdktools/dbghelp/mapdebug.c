#include <private.h>
#include <symbols.h>


PDB *
LocatePdb(
    char *szPDB,
    ULONG PdbAge,
    ULONG PdbSignature,
    GUID* PdbGuid,
    char *SymbolPath,
    char *szImageExt,
    BOOL  fImagePathPassed
    )
{
    PDB  *pdb = NULL;
    EC    ec;
    char  szError[cbErrMax] = "";
    char  szPDBSansPath[_MAX_FNAME];
    char  szPDBExt[_MAX_EXT];
    char  szPDBLocal[_MAX_PATH];
    char  szDbgPath[PDB_MAX_PATH];
    char *SemiColon;
    DWORD pass;
    EC    ecode = EC_NOT_FOUND;
    BOOL  symsrv = TRUE;
    char  szPDBName[_MAX_PATH];

    // SymbolPath is a semicolon delimited path (reference path first)



        if (SymbolPath && SymbolPath[0] !='\0') 
        {
            
            sprintf(&szPDBLocal[0],
                    "%s\\symbols\\%s\\%08X%04X%04X%02X%02X%02X%02X%02X%02X%02X%02X%01X\\%s",
                    SymbolPath,
                    szPDB,
                    PdbGuid->Data1,
                    PdbGuid->Data2,
                    PdbGuid->Data3,
                    PdbGuid->Data4[0],
                    PdbGuid->Data4[1],
                    PdbGuid->Data4[2],
                    PdbGuid->Data4[3],
                    PdbGuid->Data4[4],
                    PdbGuid->Data4[5],
                    PdbGuid->Data4[6],
                    PdbGuid->Data4[7],
                    PdbAge,
                    szPDB
                    );
        }
        else // !SymbolPath
        {
            sprintf(&szPDBLocal[0],"%s",szPDB);
        } 
   
        PDBOpenValidate(szPDBLocal, NULL, "r", PdbGuid,PdbSignature, PdbAge, &ec, szError, &pdb);

        if (ec==EC_OK)
            goto done;

        if (ec == EC_INVALID_SIG || ec == EC_INVALID_AGE) 
        {
            if (PdbSignature == 0 && PdbAge == 0) 
            {
                PDBOpen(szError, "r", 0, &ec, szError, &pdb);
            }
        } 



done:
    return pdb;
}



BOOL
ProcessPdbDebugInfo(
    PIMGHLP_DEBUG_DATA pIDD
    )
{
    PDB    *pPdb;
    Dbg    *pDbg;
    DBI    *pDbi;
    GSI    *pGsi;
    GSI    *pGlobals;
    TPI    *pTpi;
    int     DebugCount;
    void   *DebugData;
    DWORD   cpathlen = 0;
    BOOL    fImagePathPassed = FALSE;

        
    // go ahead and get it
    __debugbreak();
    pPdb = LocatePdb(pIDD->PdbFileName, 
                    pIDD->PdbAge, 
                    pIDD->PdbSignature, 
                    &pIDD->GuidSig,
                    pIDD->SymbolPath, 
                    NULL, 
                    fImagePathPassed);
    

    if (!pPdb) {
        return FALSE;
    }

    if (!PDBOpenDBI( pPdb, "r", "", &pDbi )) {
        PDBClose( pPdb );
        return FALSE;
    }

    if (!DBIOpenPublics( pDbi, &pGsi)) {
        DBIClose( pDbi );
        PDBClose( pPdb );
        return FALSE;
    }
    PDBOpenTpi(pPdb, "r", &pTpi);
    if (pTpi) 
       DBIOpenGlobals(pDbi, &pGlobals);
    
    pIDD->pPdb = pPdb;
    pIDD->pDbi = pDbi;
    pIDD->pGsi = pGsi;
    pIDD->pTpi = pTpi;
    pIDD->pGlobals = pGlobals;
    return TRUE;
}

typedef struct _NB10I{
    DWORD   dwSig;                      
    DWORD   off;                       
    DWORD   sig;
    DWORD   age;
    BYTE    szPdb[MAX_PATH];
}NB10I, *PNB10I, **PPNB10I;

typedef struct _RSDSI{
    DWORD dwSig;
    GUID  guidSig;
    DWORD age;
    BYTE  szPdb[3 * MAX_PATH];
}RSDSI, *PRSDSI, **PPRSDSI;

typedef union _CV{
    DWORD dwSig;
    NB10I nb10i;
    RSDSI rsdsi;
}XCV, *PXCV, **PPXCV;

BOOL
RetrievePdbInfo(
    PIMGHLP_DEBUG_DATA pIDD,
    CHAR const *szReference
    )
{
    PXCV pcv = (PXCV)pIDD->pMappedCv;
    BOOL rc=TRUE;
    
    if (pIDD->PdbSignature) 
    {
        goto done;
    }

    if (pcv->dwSig == '01BN')
    {
        pIDD->PdbAge = pcv->nb10i.age;
        pIDD->PdbSignature = pcv->nb10i.sig;
        strcpy(pIDD->PdbFileName, pcv->nb10i.szPdb);
    }
    else if (pcv->dwSig == 'SDSR')
    {
        pIDD->IsRSDSI = TRUE;
        pIDD->PdbAge  = pcv->rsdsi.age;
        pIDD->PdbAge  = pcv->rsdsi.age;
        pIDD->GuidSig = pcv->rsdsi.guidSig;
        strcpy(pIDD->PdbFileName, pcv->rsdsi.szPdb);
        
    }
    else
        rc = FALSE;
done:
    return rc;
}

__inline
DWORD
SectionContains (
    HANDLE hp,
    PIMAGE_SECTION_HEADER pSH,
    PIMAGE_DATA_DIRECTORY ddir
    )
{
    DWORD rva = 0;

    if (!ddir->VirtualAddress)
        return 0;

    if (ddir->VirtualAddress >= pSH->VirtualAddress) {
        if ((ddir->VirtualAddress + ddir->Size) <= (pSH->VirtualAddress + pSH->SizeOfRawData)) {
            rva = ddir->VirtualAddress;
            if (!hp) 
                rva = rva - pSH->VirtualAddress + pSH->PointerToRawData;
        }
    }

    return rva;
}

BOOL
ProcessDebugInfo(
    PIMGHLP_DEBUG_DATA pIDD,
    DWORD datasrc
    )
{
    BOOL                         status;
    ULONG                        cb;
    IMAGE_DOS_HEADER             *pdh;
    IMAGE_NT_HEADERS             *pnh;
    IMAGE_NT_HEADERS32           *pnh32;
    IMAGE_NT_HEADERS64           *pnh64;

    PIMAGE_FILE_HEADER           fh;
    PIMAGE_DEBUG_MISC            md;
    ULONG                        ddva = 0;
    ULONG                        shva = 0;
    ULONG                        nSections;
    PIMAGE_SECTION_HEADER        psh;
    IMAGE_DEBUG_DIRECTORY        *pdd;
    PIMAGE_DATA_DIRECTORY        datadir;
    PCHAR                        pCV;
    ULONG                        i;
    int                          nDebugDirs = 0;
    HANDLE                       hp;
    ULONG64                      base;

    DWORD                        rva;
    PCHAR                        filepath=NULL;
    IMAGE_EXPORT_DIRECTORY       expdir;
    DWORD                        fsize;
    BOOL                         rc = FALSE;
    USHORT                       filetype;

    __try {
        base = pIDD->InProcImageBase;
        hp   = pIDD->hProcess;
        pdh = (IMAGE_DOS_HEADER*)(ULONG_PTR)base;
        pnh = (IMAGE_NT_HEADERS*)((ULONG_PTR)base + pdh->e_lfanew);
        fh  = &pnh->FileHeader;
        switch (fh->Machine)
		{
			case IMAGE_FILE_MACHINE_AMD64:
				pnh64 = (IMAGE_NT_HEADERS64*)pnh;
				datadir = &pnh64->OptionalHeader.DataDirectory[0];
				
				pIDD->iohMagic = pnh64->OptionalHeader.Magic;
				
				// BUGBUG: get rid of this mapping!
				if (datasrc == dsImage) {
					pIDD->ImageBaseFromImage = pnh64->OptionalHeader.ImageBase;
					pIDD->ImageAlign = pnh64->OptionalHeader.SectionAlignment;
					pIDD->CheckSum = pnh64->OptionalHeader.CheckSum;
				}
				pIDD->SizeOfImage = pnh64->OptionalHeader.SizeOfImage;

				nSections = pnh64->FileHeader.NumberOfSections;
				psh = (PIMAGE_SECTION_HEADER)
					((char*)&pnh64->OptionalHeader + sizeof(IMAGE_OPTIONAL_HEADER));
				break;
			case IMAGE_FILE_MACHINE_I386:
				pnh32 = (IMAGE_NT_HEADERS32*)pnh;
				datadir = &pnh32->OptionalHeader.DataDirectory[0];
				
				pIDD->iohMagic = pnh32->OptionalHeader.Magic;
				
				// BUGBUG: get rid of this mapping!
				if (datasrc == dsImage) {
					pIDD->ImageBaseFromImage = pnh32->OptionalHeader.ImageBase;
					pIDD->ImageAlign = pnh32->OptionalHeader.SectionAlignment;
					pIDD->CheckSum = pnh32->OptionalHeader.CheckSum;
				}
				pIDD->SizeOfImage = pnh32->OptionalHeader.SizeOfImage;

				nSections = pnh32->FileHeader.NumberOfSections;
				psh = (PIMAGE_SECTION_HEADER)
					((char*)&pnh32->OptionalHeader + sizeof(IMAGE_OPTIONAL_HEADER));
				break;
			default:
				goto done;
			
        }
        // store off info to return struct
        
        pIDD->pCurrentSections = (PCHAR)psh;
        pIDD->cCurrentSections = nSections;
        pIDD->Machine = fh->Machine;
        pIDD->TimeDateStamp = fh->TimeDateStamp;
        pIDD->Characteristics = fh->Characteristics;
    

        // get information from the sections
        
        for (i = 0; i < nSections; i++, psh++) {
            DWORD offset;
    
            if (offset = SectionContains(hp, psh, &datadir[IMAGE_DIRECTORY_ENTRY_EXPORT]))
            {
                memcpy(&pIDD->expdir, base + offset, sizeof(expdir));
                pIDD->pMappedExportDirectory = (PCHAR)&pIDD->expdir;
//              pIDD->ExportedNamesSize = psh->SizeOfRawData;
                pIDD->dsExports = datasrc;
            }
            
            if (offset = SectionContains(hp, psh, &datadir[IMAGE_DIRECTORY_ENTRY_DEBUG]))
            {
                ddva = offset;
                nDebugDirs = datadir[IMAGE_DIRECTORY_ENTRY_DEBUG].Size / sizeof(IMAGE_DEBUG_DIRECTORY);
                break;
            }
        }
    
debugdirs:
        
        

    
        // read the debug directories

        while (nDebugDirs) {
            
            pdd = (char*)base + ddva;
            if (!pdd->SizeOfData) 
                goto nextdebugdir;
    
            // these debug directories are processed both in-proc and from file
    
            switch (pdd->Type) 
            {
                case IMAGE_DEBUG_TYPE_CODEVIEW:
                    pCV = (PCHAR)base + pdd->AddressOfRawData;
                    pIDD->fCvMapped = TRUE;
                    pIDD->pMappedCv = (PCHAR)pCV;
                    pIDD->cMappedCv = pdd->SizeOfData;
                    pIDD->dsCV = datasrc;
                    rc = RetrievePdbInfo(pIDD, filepath);
                    break;
            }

    
nextdebugdir:

            ddva += sizeof(IMAGE_DEBUG_DIRECTORY);
            nDebugDirs--;
        }
    
    } __except (EXCEPTION_EXECUTE_HANDLER) {

          // We might have gotten enough information
          // to be okay.  So don't indicate error.
    }
done:
    return rc;
}

