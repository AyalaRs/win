#include "pdbimpl.h"
#include "dbiimpl.h"
#include <stdio.h>

CB ConvertSymRecFmMBCSToUTF8(PSYM psymSrc, PSYM psymDest, CB cbDest)
{
	__debugbreak();
	return 0;
}
BOOL fConvertSymRecStToSz(PB pbSrc, CB cbSrc, PB pbDest, CB *pcbDest, Array<OffMap>& rgOffMap)
{
	__debugbreak();
	return 0;
}

BOOL fConvertSymRecStToSzWithSig(PB pbSrc, CB cbSrc,int xn,CB* cb)
{
	__debugbreak();
	return 0;
}
