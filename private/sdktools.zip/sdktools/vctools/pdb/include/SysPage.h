#pragma once
#if !defined(_SysPage_h)
#define _SysPage_h
namespace pdb_internal {
    class SysPage {
        DWORD   m_cbPage;
    public:
        operator DWORD() {
            if (!m_cbPage)
            {
                SYSTEM_INFO si={0};
                ::GetSystemInfo(&si);
                m_cbPage = si.dwPageSize?si.dwPageSize:0x1000;
            }
            return m_cbPage;
            }
        SysPage() {
            SYSTEM_INFO si;
            ::GetSystemInfo(&si);
            m_cbPage = si.dwPageSize;
            }
        };
    extern SysPage  cbSysPage;
    }

#endif  // _SysPage_h
