#ifndef _UTIL_MISC_H_
#define _UTIL_MISC_H_


#ifdef  __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif