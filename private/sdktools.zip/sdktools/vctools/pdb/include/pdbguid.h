#pragma once
#include <rpc.h>            // definition for UUID
BOOL FUuidCreate(UUID *);
