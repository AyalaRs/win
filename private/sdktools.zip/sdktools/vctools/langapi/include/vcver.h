#ifndef _VC_VER_INC
#define _VC_VER_INC
#ifndef _VC_VER
#define _VC_VER 550
#endif
#endif
