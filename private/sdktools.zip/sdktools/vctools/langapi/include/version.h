#define rmj		6
#define rmm		0
#define rup		7156
#define rbld    1400
#define szVerName	"Visual Studio 98"
#define szVerUser	"BryanT2"
