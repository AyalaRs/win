int __cdecl atexit()
{
	__debugbreak();
	return 0;
}