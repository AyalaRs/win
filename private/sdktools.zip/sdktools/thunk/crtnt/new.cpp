#include <stdlib.h>
void * __cdecl operator new(size_t n)
{
	return malloc(n);
}
