#include <ntifs.h>
#include <WINERROR.H>
#include "thunk.h"




int __cdecl  free(void * p)
{
	return RtlFreeHeap(RtlProcessHeap(),0,p);
}