#include <ntifs.h>
#include <WINERROR.H>
#include "thunk.h"



void * __cdecl malloc(size_t n)
{
	void* p = RtlAllocateHeap(RtlProcessHeap(),0,n);
	if (p==NULL)
		__debugbreak();
	return p;
}