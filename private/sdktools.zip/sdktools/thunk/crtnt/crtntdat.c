
#include <cruntime.h>
#include <msdos.h>
#include <rtcapi.h>
#include <dos.h>
#include <oscalls.h>
#include <mtdll.h>
#include <internal.h>
#include <stdio.h>
#include <stdlib.h>
#include <process.h>
#include <dbgint.h>

int _terrno = 0;            
unsigned long _tdoserrno = 0;  

int __app_type = _CONSOLE_APP;
int _nhandle = IOINFO_ARRAY_ELTS;

ioinfo ntioinfo[IOINFO_ARRAY_ELTS]={INVALID_HANDLE_VALUE,0,10};

ioinfo * __pioinfo[IOINFO_ARRAYS]={&ntioinfo,{0}};



int * __cdecl _errno(
        void
        )
{
        return ( &_terrno );
}

unsigned long * __cdecl __doserrno(
        void
        )
{
        return ( &_tdoserrno );
}



