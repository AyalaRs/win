
int __stdcall  InterlockedIncrement(a)
{
	__debugbreak();
	return 0;
}
int __stdcall  InterlockedDecrement(a)
{
	__debugbreak();
	return 0;
}

int __stdcall GetSystemDirectory(a,b)
{
	__debugbreak();
	return 0;
}

int __stdcall GetCurrentDirectoryA(a,b)
{
	__debugbreak();
	return 0;
}
int __stdcall GetCurrentDirectoryW(a,b)
{
	__debugbreak();
	return 0;
}

int __stdcall GetFileAttributesA(a)
{
	__debugbreak();
	return 0;
}
int __stdcall GetFileAttributesW(a)
{
	__debugbreak();
	return 0;
}
int __stdcall SetFileAttributesA(a,b)
{
	__debugbreak();
	return 0;
}
int __stdcall SetFileAttributesW(a,b)
{
	__debugbreak();
	return 0;
}

int __stdcall DeleteFileW(a)
{
	__debugbreak();
	return 0;
}

int __stdcall DeleteFileA(a)
{
	__debugbreak();
	return 0;
}

int __stdcall FindClose(a)
{
	__debugbreak();
	return 0;
}

int __stdcall FindFirstFileA(a,b)
{
	__debugbreak();
	return 0;
}
int __stdcall FindNextFileA(a,b)
{
	__debugbreak();
	return 0;
}




int __stdcall IsDebuggerPresent()
{
	return 1;
}



int __stdcall  GetEnvironmentVariableA(a,b,c)
{
	__debugbreak();
	return 0;
}

int __stdcall  HeapAlloc(a,b,c)
{
	__debugbreak();
	return 0;
}
int __stdcall  HeapReAlloc(a,b,c,d)
{
	__debugbreak();
	return 0;
}
int __stdcall  HeapFree(a,b,c)
{
	__debugbreak();
	return 0;
}
int __stdcall  HeapSize(a,b,c)
{
	__debugbreak();
	return 0;
}
int __stdcall GetCurrentProcess()
{
	__debugbreak();
	return 0;
}
int __stdcall GetCurrentProcessId()
{
	__debugbreak();
	return 0;
}
int __stdcall ReadProcessMemory(a,b,c,d,e)
{
	__debugbreak();
	return 0;
}
int __stdcall  SetFilePointerEx(a,b,c,d,e)
{
	__debugbreak();
	return 0;
}

int __stdcall  CreateDirectoryA(a,b)
{
	__debugbreak();
	return 0;
}


int __stdcall  DisableThreadLibraryCalls(a)
{
	__debugbreak();
	return 0;
}
int __stdcall  GetVersionExA(a)
{
	__debugbreak();
	return 0;
}



int __stdcall  IsDBCSLeadByte(a)
{
	__debugbreak();
	return 0;
}
int __stdcall  GetProcAddress(a,b)
{
	__debugbreak();
	return 0;
}

int __stdcall  lstrlenA(a)
{
	__debugbreak();
	return 0;
}

int __stdcall  FreeLibrary(a)
{
	__debugbreak();
	return 0;
}
int __stdcall  LoadLibraryA(a)
{
	__debugbreak();
	return 0;
}

int __stdcall  lstrcpyA(a,b)
{
	__debugbreak();
	return 0;
}
int __stdcall  ExpandEnvironmentStringsA(a,b,c)
{
	__debugbreak();
	return 0;
}



int __stdcall  LoadLibraryExW(a,b,c)
{
	__debugbreak();
	return 0;
}


int __stdcall  UuidCreate(a)
{
	__debugbreak();
	return 0;
}//rpc

int __stdcall  DeleteCriticalSection(a)
{
	__debugbreak();
	return 0;
}
int __stdcall  EnterCriticalSection(a)
{
	__debugbreak();
	return 0;
}
int __stdcall  LeaveCriticalSection(a)
{
	__debugbreak();
	return 0;
}
int __stdcall  InitializeCriticalSectionAndSpinCount(a,b)
{
	__debugbreak();
	return 0;
}
int __stdcall  ExpandEnvironmentStringsW(a,b,c)
{
	__debugbreak();
	return 0;
}
int __stdcall  RegCloseKey(a)
{

	__debugbreak();
	return 0;
}
int __stdcall  RegQueryValueExW(a,b,c,d,e,f)
{

	__debugbreak();
	return 0;
}
int __stdcall  RegOpenKeyExW(a,b,c,d,e)
{

	__debugbreak();
	return 0;
}


int __stdcall  OutputDebugStringA(a)
{
	
	return 0;
}
int __stdcall  OutputDebugStringW(a)
{
	
	return 0;
}
int __stdcall  GetDriveTypeW(a)
{
	return 0;//DRIVE_UNKNOWN
}
