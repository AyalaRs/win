#include <ntifs.h>
#include <WINERROR.H>
#include "thunk.h"



TDB tdb={0};
PDB udb={0};



TDB* __stdcall
NtCurrentTDB()
{
	return &tdb;
}

PDB* __stdcall
NtCurrentPDB()
{
	return &udb;
}

HANDLE __stdcall
RtlProcessHeap()
{
	if (!udb.ProcessHeap)
		udb.ProcessHeap = RtlCreateHeap(HEAP_CLASS_1,NULL,4096*2000,4096*400,0,NULL);
	return udb.ProcessHeap;
}

					 


PLARGE_INTEGER
BaseFormatTimeOut(
    OUT PLARGE_INTEGER TimeOut,
    IN DWORD Milliseconds
    )
{
    if ( (LONG) Milliseconds == -1 ) {
        return( NULL );
        }
    TimeOut->QuadPart = UInt32x32To64( Milliseconds, 10000 );
    TimeOut->QuadPart *= -1;
    return TimeOut;
}


PUNICODE_STRING
Basep8BitStringToStaticUnicodeString(
    IN LPCSTR lpSourceString
    )

/*++

Routine Description:

    Captures and converts a 8-bit (OEM or ANSI) string into the Teb Static
    Unicode String

Arguments:

    lpSourceString - string in OEM or ANSI

Return Value:

    Pointer to the Teb static string if conversion was successful, NULL
    otherwise.  If a failure occurred, the last error is set.

--*/

{
    PUNICODE_STRING StaticUnicode;
    ANSI_STRING AnsiString;
    NTSTATUS Status;

    //
    //  Get pointer to static per-thread string
    //

    StaticUnicode = &NtCurrentTeb()->StaticUnicodeString;

    //
    //  Convert input string into unicode string
    //

    RtlInitAnsiString( &AnsiString, lpSourceString );
    Status = RtlAnsiStringToUnicodeString( StaticUnicode, &AnsiString, FALSE );

    //
    //  If we couldn't convert the string
    //

    if ( !NT_SUCCESS( Status ) ) {
        if ( Status == STATUS_BUFFER_OVERFLOW ) {
            SetLastError( ERROR_FILENAME_EXCED_RANGE );
        } else {
            BaseSetLastNTError( Status );
        }
        return NULL;
    } else {
        return StaticUnicode;
    }
}

BOOL
Basep8BitStringToDynamicUnicodeString(
    OUT PUNICODE_STRING UnicodeString,
    IN LPCSTR lpSourceString
    )
/*++

Routine Description:

    Captures and converts a 8-bit (OEM or ANSI) string into a heap-allocated
    UNICODE string

Arguments:

    UnicodeString - location where UNICODE_STRING is stored

    lpSourceString - string in OEM or ANSI

Return Value:

    TRUE if string is correctly stored, FALSE if an error occurred.  In the
    error case, the last error is correctly set.

--*/

{
    ANSI_STRING AnsiString;
    NTSTATUS Status;

    //
    //  Convert input into dynamic unicode string
    //

    RtlInitString( &AnsiString, lpSourceString );
    Status = RtlAnsiStringToUnicodeString( UnicodeString, &AnsiString, TRUE );

    //
    //  If we couldn't do this, fail
    //

    if (!NT_SUCCESS( Status )){
        if ( Status == STATUS_BUFFER_OVERFLOW ) {
            SetLastError( ERROR_FILENAME_EXCED_RANGE );
        } else {
            BaseSetLastNTError( Status );
        }
        return FALSE;
        }

    return TRUE;
}
