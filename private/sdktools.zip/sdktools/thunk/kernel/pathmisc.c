#include <ntifs.h>
#include <WINERROR.H>
#include "thunk.h"


DWORD
APIENTRY
GetFullPathNameA(
    LPCSTR lpFileName,
    DWORD nBufferLength,
    LPSTR lpBuffer,
    LPSTR *lpFilePart
    )
{
	int cb;
	cb = strlen(lpFileName);
	if (cb > nBufferLength)
		cb = nBufferLength;
	if (lpBuffer)
		RtlMoveMemory(lpBuffer,lpFileName,cb);
	lpBuffer[cb]='\0';
	if (lpFilePart)
	{
		int i;
		for (i=cb;i>0;i--)
		{
			if (lpFileName[i]=='\\')
				break;
		}
		lpFilePart = &lpFileName[i+1];
	}
		
done:
	return cb;
}

DWORD
APIENTRY
GetFullPathNameW(
    LPCWSTR lpFileName,
    DWORD nBufferLength,
    LPWSTR lpBuffer,
    LPWSTR *lpFilePart
    )
{
	int cb;
	cb = wcslen(lpFileName);
	if (cb > nBufferLength)
		cb = nBufferLength;
	if (lpBuffer)
		RtlMoveMemory(lpBuffer,lpFileName,2*cb);
	lpBuffer[cb]=L'\0';
	if (lpFilePart)
	{
		int i;
		for (i=cb;i>0;i--)
		{
			if (lpFileName[i]==L'\\')
				break;
		}
		lpFilePart = &lpFileName[i+1];
	}
		
done:
	return cb;
}