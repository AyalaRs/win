/*++

Copyright (c) 1991-1996,  Microsoft Corporation  All rights reserved.

Module Name:

    mbcs.c

Abstract:

    This file contains functions that convert multibyte character strings
    to wide character strings, convert wide character strings to multibyte
    character strings, convert a multibyte character string from one code
    page to a multibyte character string of another code page, and get the
    DBCS leadbyte ranges for a given code page.

    APIs found in this file:
      MultiByteToWideChar
      WideCharToMultiByte

Revision History:

    05-31-91    JulieB    Created.

--*/



//
//  Include Files.
//

#include <ntifs.h>
#include <WINERROR.H>
#include "thunk.h"


////////////////////////////////////////////////////////////////////////////
//
//  MultiByteToWideChar
//
//  Maps a multibyte character string to its wide character string
//  counterpart.
//
//  05-31-91    JulieB    Created.
//  09-01-93    JulieB    Add support for MB_ERR_INVALID_CHARS flag.
////////////////////////////////////////////////////////////////////////////

int WINAPI MultiByteToWideChar(
    UINT CodePage,
    DWORD dwFlags,
    LPCSTR lpMultiByteStr,
    int cchMultiByte,
    LPWSTR lpWideCharStr,
    int cchWideChar)
{
 
    UINT cp;

    if (CodePage == CP_ACP)
       cp = CP_UTF8;
    else
       cp = CodePage;
    if (cp >= CP_UTF7)
    {
        return (UTFToUnicode( cp,
                              dwFlags,
                              lpMultiByteStr,
                              cchMultiByte,
                              lpWideCharStr,
                              cchWideChar ));
    }
    else
        return 0;
}


////////////////////////////////////////////////////////////////////////////
//
//  WideCharToMultiByte
//
//  Maps a wide character string to its multibyte character string
//  counterpart.
//
//  NOTE:  Most significant bit of dwFlags parameter is used by this routine
//         to indicate that the caller only wants the count of the number of
//         characters written, not the string (ie. do not back up in buffer).
//
//  05-31-91    JulieB    Created.
////////////////////////////////////////////////////////////////////////////

int WINAPI WideCharToMultiByte(
    UINT CodePage,
    DWORD dwFlags,
    LPCWSTR lpWideCharStr,
    int cchWideChar,
    LPSTR lpMultiByteStr,
    int cchMultiByte,
    LPCSTR lpDefaultChar,
    LPBOOL lpUsedDefaultChar)
{
    UINT cp;

    //
    //  See if it's a special code page value for UTF translations.
    //
    if (CodePage == CP_ACP)
       cp = CP_UTF8;
    else
       cp = CodePage;
    if (cp >= CP_UTF7)
    {
        return (UnicodeToUTF( cp,
                              dwFlags,
                              lpWideCharStr,
                              cchWideChar,
                              lpMultiByteStr,
                              cchMultiByte,
                              lpDefaultChar,
                              lpUsedDefaultChar ));
    }
    else
        return 0;
}



