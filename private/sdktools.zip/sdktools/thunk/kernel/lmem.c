/*++

Copyright (c) 1990  Microsoft Corporation

Module Name:

    lmem.c

Abstract:

    This module contains the Win32 Local Memory Management APIs

Author:

    Steve Wood (stevewo) 24-Sep-1990

Revision History:

--*/

#include <ntifs.h>
#include <WINERROR.H>
#include "thunk.h"



#if i386
#pragma optimize("y",off)
#endif

HLOCAL
WINAPI
LocalAlloc(
    UINT uFlags,
    SIZE_T uBytes
    )
{
    PBASE_HANDLE_TABLE_ENTRY HandleEntry;
    HANDLE hMem;
    ULONG Flags;
    LPSTR p=NULL;
	__debugbreak();
    Flags = 0;
    if (uFlags & LMEM_ZEROINIT) {
        Flags |= HEAP_ZERO_MEMORY;
        }

    if (!(uFlags & LMEM_MOVEABLE)) {
        p = RtlAllocateHeap( BaseHeap,
                             Flags,
                             uBytes
                           );
        if (p == NULL) {
            SetLastError( ERROR_NOT_ENOUGH_MEMORY );
            }

        return( p );
        }

    return( (HANDLE)p );
}


HLOCAL
WINAPI
LocalReAlloc(
    HLOCAL hMem,
    SIZE_T uBytes,
    UINT uFlags
    )
{
	__debugbreak();
    return( (LPSTR)hMem );
}



SIZE_T
WINAPI
LocalSize(
    HLOCAL hMem
    )
{
    PBASE_HANDLE_TABLE_ENTRY HandleEntry;
    PVOID Handle;
    ULONG Flags;
    SIZE_T uSize;
	__debugbreak();
    uSize = MAXULONG_PTR;

    try 
	{
        uSize = RtlSizeHeap( BaseHeap, HEAP_NO_SERIALIZE, (PVOID)hMem );
    }
    except (EXCEPTION_EXECUTE_HANDLER) 
	{
        BaseSetLastNTError( GetExceptionCode() );
    }

    if (uSize == MAXULONG_PTR) {
        SetLastError( ERROR_INVALID_HANDLE );
        return 0;
        }
    else {
        return uSize;
        }
}


HLOCAL
WINAPI
LocalFree(
    HLOCAL hMem
    )
{
    PBASE_HANDLE_TABLE_ENTRY HandleEntry;
    LPSTR p;
	__debugbreak();
    try 
	{
        if (!((ULONG_PTR)hMem & BASE_HANDLE_MARK_BIT)) 
		{
            if (RtlFreeHeap( BaseHeap,
                             0,
                             (PVOID)hMem
                           )
               ) 
			{
                return NULL;
            }
            else 
			{
                SetLastError( ERROR_INVALID_HANDLE );
                return hMem;
            }
        }
    }
    except (EXCEPTION_EXECUTE_HANDLER) 
	{
        BaseSetLastNTError( GetExceptionCode() );
        return hMem;
    }
}



HANDLE
WINAPI
HeapCreate(
    DWORD flOptions,
    SIZE_T dwInitialSize,
    SIZE_T dwMaximumSize
    )
{
    HANDLE hHeap;
    ULONG Flags;
	__debugbreak();

    Flags = (flOptions & (HEAP_GENERATE_EXCEPTIONS | HEAP_NO_SERIALIZE)) | HEAP_CLASS_1;
 

    hHeap = (HANDLE)RtlCreateHeap( Flags,
                                   NULL,
                                   dwMaximumSize,
                                   dwInitialSize,
                                   0,
                                   NULL
                                 );
    if (hHeap == NULL) {
        SetLastError( ERROR_NOT_ENOUGH_MEMORY );
        }

    return( hHeap );
}

BOOL
WINAPI
HeapDestroy(
    HANDLE hHeap
    )
{
	__debugbreak();
    if (RtlDestroyHeap( (PVOID)hHeap ) == NULL ) {
        return( TRUE );
        }
    else {
        SetLastError( ERROR_INVALID_HANDLE );
        return( FALSE );
        }
}
