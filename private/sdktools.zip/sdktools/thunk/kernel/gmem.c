#include <ntifs.h>
#include <WINERROR.H>
#include "thunk.h"

BOOL
WINAPI
VirtualProtect(
    PVOID lpAddress,
    SIZE_T dwSize,
    DWORD flNewProtect,
    PDWORD lpflOldProtect
    )
{
	return TRUE;
}

PVOID
WINAPI
VirtualAlloc(
    PVOID lpAddress,
    SIZE_T dwSize,
    DWORD flAllocationType,
    DWORD flProtect
    )
{
	if (lpAddress)
		return lpAddress;
	else
		return RtlAllocateHeap( BaseHeap,
									 0,
									 dwSize
								   );
}

BOOL
WINAPI
VirtualFree(
    LPVOID lpAddress,
    SIZE_T dwSize,
    DWORD dwFreeType
    )
{
	if (dwFreeType == MEM_RELEASE)
	{
		return RtlFreeHeap( BaseHeap,
					 0,
					 lpAddress
				    );
	}
	else
		return TRUE;
}