/*++

Copyright (c) 1990  Microsoft Corporation

Module Name:

    module.c

Abstract:

    This module contains the Win32 Module Management APIs

Author:

    Steve Wood (stevewo) 24-Sep-1990

Revision History:

--*/
#include <ntifs.h>
#include <WINERROR.H>
#include "thunk.h"

typedef struct _RTL_PROCESS_MODULE_INFORMATION {
    HANDLE Section;                 // Not filled in
    PVOID MappedBase;
    PVOID ImageBase;
    ULONG ImageSize;
    ULONG Flags;
    USHORT LoadOrderIndex;
    USHORT InitOrderIndex;
    USHORT LoadCount;
    USHORT OffsetToFileName;
    UCHAR  FullPathName[ 256 ];
} RTL_PROCESS_MODULE_INFORMATION, *PRTL_PROCESS_MODULE_INFORMATION;

typedef struct _RTL_PROCESS_MODULES {
    ULONG NumberOfModules;
    RTL_PROCESS_MODULE_INFORMATION Modules[ 1 ];
} RTL_PROCESS_MODULES, *PRTL_PROCESS_MODULES;

HMODULE
GetModuleHandleA(
    LPCSTR lpModuleName
    )
{
	size_t cbsi=0,cbm;
	NTSTATUS status;
	HMODULE hMod=NULL;
	PRTL_PROCESS_MODULES pMi;
	int i;
	status=
	ZwQuerySystemInformation(
							SystemModuleInformation,
							NULL,
							NULL,
							&cbsi);
	if (!NT_SUCCESS(status) && status !=STATUS_INFO_LENGTH_MISMATCH)
		goto done;
	
	pMi = RtlAllocateHeap( BaseHeap,
					     0,
					    cbsi
				         );
	if (!pMi)
		goto done;
	
	status=
	ZwQuerySystemInformation(
							SystemModuleInformation,
							pMi,
							&cbsi,
							NULL);
							
	if (!NT_SUCCESS(status))
		goto done;

	cbm = strlen(lpModuleName);
	for (i=0;i<pMi->NumberOfModules;i++)
	{
		char* s=strstr(&pMi->Modules[i].FullPathName,lpModuleName);
		if (s != NULL && strlen(s)==cbm)
		{
			hMod = pMi->Modules[i].ImageBase;
			goto done;
		}
	}
	
	
done:
	return hMod;
}
