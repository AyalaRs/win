#include <ntdef.h>
#include <ntddk.h>

#include "thunk.h"
#define printf(f,...) DbgPrintEx(DPFLTR_SETUP_ID,DPFLTR_INFO_LEVEL,f,__VA_ARGS__)

int __stdcall
FindLocal(
	PSTR SymbolName,
    DWORD64 SymbolAddress,
    ULONG SymbolSize,
    PVOID UserContext
    )
{
	
	printf("%016I64X\n  %s\n",SymbolAddress,SymbolName);
	return 1;
}

int __stdcall 
DriverEntry(PDRIVER_OBJECT pDriverObject, PUNICODE_STRING pRegistryPath)
{
	int status;
	DWORD64 mod;
	DWORD64 BaseOfDll;
	HANDLE hProcess;
	char buf[260];
	char* tag[2];
	int i;
#if DBG
		if (IsDebuggerPresent())
			__debugbreak();
#endif

	hProcess = -1;

	status=
	SymSetSearchPath(hProcess,
					"C:");
 


	tag[0]="ntoskrnl.exe";
	tag[1]="ntkrnlmp.exe";

	for (i=0;i<2;i++)
	{
		BaseOfDll=(DWORD64)GetModuleHandleA(tag[i]);
		if (BaseOfDll)
			break;
	}
	printf("BaseOfDll %016I64X\n",BaseOfDll);
	if (!BaseOfDll)
		goto done;
/*
	
	GetSystemDirectory(buf,sizeof(buf));
	strcat(buf,"\\");
	strcat(buf,tag[0]);
	printf("%s\n",buf);



	mod=
	SymLoadModule64(hProcess,
					NULL,
					buf,
					NULL,
					BaseOfDll,
					0);
					
	if (!mod)
	{
		printf("SymLoadModule64 fault %08X\n",GetLastError());
		goto done;
	}
	SymEnumerateSymbols64 (hProcess,
						BaseOfDll,
						&FindLocal,
						NULL
						);
						*/
	SymEnumerateTypes64 (hProcess,
						BaseOfDll,
						&FindLocal,
						NULL
						);

	RtlDestroyHeap(RtlProcessHeap());
done:
#if DBG
		if (IsDebuggerPresent())
			__debugbreak();
#endif
	return STATUS_DEVICE_CONFIGURATION_ERROR;
}

