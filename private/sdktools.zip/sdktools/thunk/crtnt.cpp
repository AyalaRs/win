#include <ntifs.h>
#include <WINERROR.H>
#include "thunk.h"

#if 1
#ifdef __cplusplus
extern "C" {
#endif
#ifndef _WIN64
BOOL __cdecl _ValidateImageBase(
    PBYTE pImageBase
    )
{
	__debugbreak();
    return TRUE;
}

PVOID __cdecl _FindPESection(
    PBYTE     pImageBase,
    DWORD     rva
    )
{
	__debugbreak();
    return NULL;
}
#endif

int __cdecl  _makepath()
{
	__debugbreak();
	return 0;
}
int __cdecl  _splitpath()
{
	__debugbreak();
	return 0;
}

int __cdecl printf(const char* f,...)
{
	__debugbreak();
	return 0;
}

wchar_t * __cdecl  _wcsdup(const wchar_t * _Str)
{
	__debugbreak();
	return 0;
}

int __cdecl  _ltoa()
{
	__debugbreak();
	return 0;
}

int __cdecl  time()
{
	__debugbreak();
	return 0;
}

int __cdecl  _wsopen_s()
{
	__debugbreak();
	return 0;
}
int __cdecl  _wgetenv()
{
	__debugbreak();
	return 0;
}
int __cdecl  _access_s()
{
	__debugbreak();
	return 0;
}


int __cdecl  _fullpath()
{
	__debugbreak();
	return 0;
}



int __cdecl  _wfsopen()
{
	__debugbreak();
	return 0;
}
int __cdecl  fclose()
{
	__debugbreak();
	return 0;
}
int __cdecl  fread()
{
	__debugbreak();
	return 0;
}
int __cdecl  fseek()
{
	__debugbreak();
	return 0;
}
int __cdecl  ftell()
{
	__debugbreak();
	return 0;
}



#ifdef __cplusplus
}
#endif
#endif
