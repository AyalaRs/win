#include <ntifs.h>
#include "thunk.h"

NTSTATUS
NTAPI
ZwCreateIoCompletion (
    __out PHANDLE IoCompletionHandle,
    __in ACCESS_MASK DesiredAccess,
    __in_opt POBJECT_ATTRIBUTES ObjectAttributes,
    __in ULONG Count OPTIONAL
    )

{
	return STATUS_UNSUCCESSFUL;
}

NTSTATUS
NTAPI
ZwRemoveIoCompletion (
    __in HANDLE IoCompletionHandle,
    __out PVOID *KeyContext,
    __out PVOID *ApcContext,
    __out PIO_STATUS_BLOCK IoStatusBlock,
    __in_opt PLARGE_INTEGER Timeout
    )

{
	return STATUS_UNSUCCESSFUL;
}
