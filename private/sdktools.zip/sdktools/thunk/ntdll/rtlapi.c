#include <ntifs.h>
#include "thunk.h"

BOOLEAN
__stdcall
RtlDosPathNameToNtPathName_U(
    __in PCWSTR DosFileName,
    __out PUNICODE_STRING NtFileName,
    __out_opt PWSTR *FilePart,
    __out PRTL_RELATIVE_NAME_U RelativeName
    )
{
	NTSTATUS Status;
	
	if (RelativeName)
		RtlZeroMemory(RelativeName,sizeof(RTL_RELATIVE_NAME_U));
	
	Status = RtlInitUnicodeStringEx(NtFileName,DosFileName);
	if (!NT_SUCCESS(Status))
		goto done;
	
	NtFileName->Buffer = RtlAllocateHeap(BaseHeap,0,(MAX_PATH+9) * sizeof(wchar_t));
	if (!NtFileName->Buffer)
	{
		Status = STATUS_INSUFFICIENT_RESOURCES;
		goto done;
	}
	RtlMoveMemory(&NtFileName->Buffer[0],L"\\??\\",8);
	RtlMoveMemory(&NtFileName->Buffer[4],DosFileName,NtFileName->MaximumLength);
	
	NtFileName->Length       +=8;
	NtFileName->MaximumLength = (MAX_PATH+9) * sizeof(wchar_t);
done:
	return NT_SUCCESS(Status);
}
